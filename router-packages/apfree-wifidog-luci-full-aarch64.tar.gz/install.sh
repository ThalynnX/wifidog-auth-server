#!/bin/sh
# apfree-wifidog 9.11.2969 + LuCI 面板 一键手动安装
# 目标：JDCloud RE-SS-01 (qualcommax/ipq60xx) ImmortalWRT SNAPSHOT apk 系统
set -e
BK=/tmp/wifidog-backup-$(date +%Y%m%d-%H%M%S)
echo "[1/5] 备份到 $BK"
for f in usr/bin/wifidogx usr/bin/wdctlx etc/config/wifidogx etc/init.d/wifidogx; do
  [ -f "/$f" ] && mkdir -p "$BK/$(dirname $f)" && cp -a "/$f" "$BK/$f" || true
done

echo "[2/5] 安装文件"
cp -a usr /etc /www / 2>/dev/null || true
chmod 755 /usr/bin/wifidogx /usr/bin/wdctlx /etc/init.d/wifidogx

echo "[3/5] 注册开机启动"
/etc/init.d/wifidogx enable 2>/dev/null || true

echo "[4/5] 清理 LuCI 缓存并重启 rpcd"
rm -rf /tmp/luci-indexcache* /tmp/luci-modulecache 2>/dev/null || true
/etc/init.d/rpcd restart 2>/dev/null || true

echo "[5/5] 校验依赖库"
MISS=0
for lib in libz.so.1 libjson-c.so.5 libssl.so.3 libcrypto.so.3 libevent-2.1.so.7 \
           libevent_openssl-2.1.so.7 libnetfilter_queue.so.1 libmosquitto.so.1 \
           libuci.so.20250120 libnftnl.so.11 libmnl.so.0; do
  if [ ! -e "/usr/lib/$lib" ] && [ ! -e "/lib/$lib" ]; then echo "  缺少: $lib"; MISS=1; fi
done
[ $MISS -eq 0 ] && echo "  依赖齐全" || echo "  缺库会导致 wifidogx 起不来，把上面的名字发我，我从构建产物里挑给你"

cat <<'EOF'

安装完成。接下来：
  1) LuCI 里刷新页面，应出现「服务 → ApFree-WiFiDog」
  2) 默认 enabled=0（未启用），先进面板把「启用」打开
  3) 模式选 Local Auth 时填本地门户 URL，不需要认证服务器
  4) 完成后执行：/etc/init.d/wifidogx start，再看 /etc/init.d/wifidogx status
备份目录：$BK
EOF
